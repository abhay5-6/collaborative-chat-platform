from sqlalchemy import (
    ForeignKey,
    String,
    DateTime
)
from datetime import datetime
from sqlalchemy.orm import (
    Mapped,
    mapped_column
)

from app.db.database import Base


class RoomMembership(Base):
    __tablename__ = "room_memberships"

    id: Mapped[int] = mapped_column(
        primary_key=True
    )

    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id")
    )

    room_id: Mapped[int] = mapped_column(
        ForeignKey("rooms.id")
    )    

    role: Mapped[str] = mapped_column(
        String(20),
        default="member"
    )

    joined_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow
    )
    